let employees = [{ name: "Bharati shendurkar", age: "21", city: "Amravati", salary: 50000, },
{ name: "Dhanshree warghat", age: "22", city: "Mumbai", salary: 56000, },
{ name: "Ankita Kharabe", age: "20", city: "pune", salary: 23000, },
{ name: "Prajwal Rathod", age: "24", city: "Akola", salary: 29000, },
{ name: "Shweta satnurkar", age: "30", city: "Aurangabad", salary: 9000, },
];
function display(employeeArray) {
    let tabledata = "";
    let SrNo = 1;

    employeeArray.forEach(function (employee, index) {
        let currentRow = `<tr>
        <td>${SrNo}</td>
        <td>${employee.name}</td>
        <td>${employee.age}</td>
        <td>${employee.city}</td>
        <td>${employee.salary}</td>
        <td><button onclick="deleteEmployess(${index})">Delete</button></td>
        </tr>`;
        tabledata += currentRow;
        SrNo++;
    });
    document.getElementsByClassName('tdata')[0].innerHTML = tabledata;
}
display(employees);
//second step adding  employess
function addEmployee(event) {
    event.preventDefault();
    let employee = {};
    let name = document.getElementById('name').value;
    let age = document.getElementById('age').value;
    let city = document.getElementById('city').value;
    let salary = document.getElementById('salary').value;
    console.log(name, age, city, salary);
    employee.name = name;
    employee.age = Number(age);
    employee.city = city;
    employee.salary = salary;
    employees.push(employee)
    console.log(employees);
    display(employees);
    document.getElementById('name').value = "";
    document.getElementById('age').value = "";
    document.getElementById('city').value = "";
    document.getElementById('salary').value = "";
}
//search by Name
function searchByName() {
    let searchValue = document.getElementById('searchName').value;
    //console.log(searchValue);
    let newData = employees.filter(function (employee) {
        return (employee.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
        );
    });
    //console.log(newData);
    display(newData);
}
//search by city
function searchByCity() {
    let searchCity = document.getElementById('searchCity').value;
    //console.log(searchCity);
    let cityData = employees.filter(function (employee) {
        return (employee.city.toUpperCase().indexOf(searchCity.toUpperCase()) != -1
        );
    });
    //console.log(newData);
    display(cityData);
}

function deleteEmployess(index) {
    employees.splice(index, 1);
    display(employees);


}