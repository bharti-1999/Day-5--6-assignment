
window.onload = function () {
  let initialbuses = [{
    name: 'Chintamani',
    source: 'Yawatmal',
    destination: "Pune",
    number: "MH.AW.8999",
    passenger: 45,
  },
  {
    name: 'Yash',
    source: 'pune',
    destination: "mumbai",
    number: "MH.AW.8979",
    passenger: 65,
  },
  {
    name: 'Mahalakshami travells',
    source: 'mumbai',
    destination: "Surat",
    number: "MH.AW.8579",
    passenger: 50,
  }];
  if (localStorage.getItem("buses") == null) {
    localStorage.setItem("buses",JSON.stringify(initialbuses));
}
};

function display(busArray=undefined) {
  let tabledata = "";
  let buses;
if (busArray==undefined) {
  buses=JSON.parse(localStorage.getItem('buses'))
}
else{
  buses=busArray;
}
 
buses.forEach(function (bus, index) {
    let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${bus.name}</td>
      <td>${bus.source}</td>
      <td>${bus.destination}</td>
      <td>${bus.number}</td>
      <td>${bus.passenger}</td>
      <button onclick="deleteBus(${index})">Delete</button>     
      <button onclick="showModal(${index})">Update</button>
</tr>`
    tabledata += currentrow;
  });
  document.getElementsByClassName('tdata')[0].innerHTML = tabledata;
}
display();

//add the bus details

function addBus(event) {
  event.preventDefault();
  let bus = {};
  let name = document.getElementById("name").value;
  let source = document.getElementById("source").value;
  let destination = document.getElementById("destination").value;
  let number = document.getElementById("number").value;
  let passenger = document.getElementById("passenger").value;
  bus.name = name;
  bus.source = source;
  bus.destination = destination;
  bus.number = number;
  bus.passenger = passenger;

  let buses = JSON.parse(localStorage.getItem("buses"));
   buses.push(bus);
  localStorage.setItem("buses", JSON.stringify(buses));
display();
  //to clear the  input field
  document.getElementById("name").value = "";
  document.getElementById("source").value = "";
  document.getElementById("destination").value = "";
  document.getElementById("number").value = "";
  document.getElementById("passenger").value = "";
}
function searchBySource() {
 let searchSource = document.getElementById("searchSource").value;
 let buses=JSON.parse(localStorage.getItem("buses"));
  let sourcedata = buses.filter(function (bus) {
    return (
      bus.source.toUpperCase().indexOf(searchSource.toUpperCase()) != -1
    );
  });
 
  display(sourcedata);

}

function deleteBus(index) {
  let buses = JSON.parse(localStorage.getItem("buses"));
  buses.splice(index, 1);
  display();
  localStorage.setItem("buses", JSON.stringify(buses));
display();
}
let updateIndex;

function copyBus(index) {
  let buses = JSON.parse(localStorage.getItem("buses"));
  updateIndex = index;
  //console.log(updateIndex);
  let bus = buses[updateIndex];
  document.getElementById("updatename").value = bus.name;
  document.getElementById("updatesource").value = bus.source;
  document.getElementById("updatedestination").value = bus.destination;
  document.getElementById("updatenumber").value = bus.number;
  document.getElementById("updatepassenger").value = bus.passenger;
}


function updateBus(event) {
  let buses = JSON.parse(localStorage.getItem("buses"));
  event.preventDefault();
  let bus = buses[updateIndex];
  console.log(bus);
  let name = document.getElementById("updatename").value;
  let source = document.getElementById("updatesource").value;
  let destination = document.getElementById("updatedestination").value;
  let number = document.getElementById("updatenumber").value;
  let passenger = document.getElementById("updatepassenger").value;
  bus.name = name;
  bus.source = source;
  bus.destination = destination;
  bus.number = number;
  bus.passenger = passenger;
  localStorage.setItem("buses", JSON.stringify(buses));
  display(buses);
  
  let modal = document.getElementsByClassName("modal")[0];
  modal.style.display = "none"

}
function showModal(index) {
  let modal = document.getElementsByClassName("modal")[0];
  modal.style.display = "block"
  copyBus(index);
}
function hideModal(event) {
  if (event.target.className == "modal") {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none"
  }

}



